"use client"

import { useEffect, useRef, useState } from "react"
import { Sparkles, Users, Calendar, Heart } from "lucide-react"
import Image from "next/image"

const services = [
  {
    icon: Heart,
    title: "Bodas de Ensueño",
    description: "Diseñamos y coordinamos cada detalle de tu día especial, desde la ceremonia hasta la última canción.",
    image: "/elegant-wedding-ceremony-with-bride-and-groom--rom.jpg",
  },
  {
    icon: Sparkles,
    title: "Eventos Corporativos",
    description: "Creamos experiencias profesionales memorables que reflejan la identidad de tu marca.",
    image: "/sophisticated-corporate-event--business-conference.jpg",
  },
  {
    icon: Users,
    title: "Celebraciones Privadas",
    description: "Aniversarios, cumpleaños y eventos íntimos diseñados con atención personalizada.",
    image: "/elegant-private-party-celebration--intimate-gather.jpg",
  },
  {
    icon: Calendar,
    title: "Planificación Integral",
    description: "Gestión completa desde la conceptualización hasta la ejecución perfecta del evento.",
    image: "/professional-event-planning-setup--detailed-organi.jpg",
  },
]

export function Services() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section id="servicios" ref={sectionRef} className="py-24 md:py-32 bg-background">
      <div className="container mx-auto px-4 lg:px-8">
        <div
          className={`text-center mb-16 transition-all duration-1000 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
          }`}
        >
          <h2
            className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold mb-6 text-balance"
            style={{ fontFamily: "var(--font-playfair)" }}
          >
            Nuestros Servicios
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto text-pretty leading-relaxed">
            Cada evento es único. Ofrecemos soluciones personalizadas que se adaptan a tu visión y superan tus
            expectativas.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
          {services.map((service, index) => {
            const Icon = service.icon
            return (
              <div
                key={index}
                className={`group rounded-lg overflow-hidden bg-card border border-border transition-all duration-500 hover:shadow-2xl hover:-translate-y-2 ${
                  isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
                }`}
                style={{ transitionDelay: `${index * 100}ms` }}
              >
                <div className="relative h-64 overflow-hidden">
                  <Image
                    src={service.image || "/placeholder.svg"}
                    alt={service.title}
                    fill
                    className="object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/40 to-transparent" />
                  <div className="absolute bottom-4 left-6 inline-flex p-3 rounded-full bg-accent/90 backdrop-blur-sm">
                    <Icon className="text-accent-foreground" size={28} />
                  </div>
                </div>
                <div className="p-8">
                  <h3 className="text-2xl font-serif font-semibold mb-4" style={{ fontFamily: "var(--font-playfair)" }}>
                    {service.title}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">{service.description}</p>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
