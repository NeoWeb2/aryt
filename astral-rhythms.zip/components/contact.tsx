"use client"

import type React from "react"

import { useEffect, useRef, useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Mail, Phone, MapPin } from "lucide-react"

export function Contact() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Form submission logic would go here
    alert("Gracias por tu mensaje. Te contactaremos pronto.")
  }

  return (
    <section id="contacto" ref={sectionRef} className="py-24 md:py-32 bg-muted/30">
      <div className="container mx-auto px-4 lg:px-8">
        <div
          className={`text-center mb-16 transition-all duration-1000 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
          }`}
        >
          <h2
            className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold mb-6 text-balance"
            style={{ fontFamily: "var(--font-playfair)" }}
          >
            Hablemos de tu Evento
          </h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 max-w-6xl mx-auto">
          <div
            className={`transition-all duration-1000 delay-200 ${
              isVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-10"
            }`}
          >
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium mb-2">
                    Nombre
                  </label>
                  <Input id="name" placeholder="Tu nombre" required />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium mb-2">
                    Email
                  </label>
                  <Input id="email" type="email" placeholder="tu@email.com" required />
                </div>
              </div>

              <div>
                <label htmlFor="phone" className="block text-sm font-medium mb-2">
                  Teléfono
                </label>
                <Input id="phone" type="tel" placeholder="+34 600 000 000" />
              </div>

              <div>
                <label htmlFor="event-type" className="block text-sm font-medium mb-2">
                  Tipo de Evento
                </label>
                <Input id="event-type" placeholder="Boda, Corporativo, Celebración..." required />
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium mb-2">
                  Cuéntanos sobre tu evento
                </label>
                <Textarea
                  id="message"
                  placeholder="Describe tu visión, fecha estimada, número de invitados..."
                  rows={6}
                  required
                />
              </div>

              <Button type="submit" size="lg" className="w-full bg-primary text-primary-foreground hover:bg-primary/90">
                Enviar Mensaje
              </Button>
            </form>
          </div>

          <div
            className={`transition-all duration-1000 delay-400 ${
              isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-10"
            }`}
          >
            <div className="space-y-8">
              <div>
                <h3 className="text-2xl font-serif font-semibold mb-6" style={{ fontFamily: "var(--font-playfair)" }}>
                  Información de Contacto
                </h3>
                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <div className="p-3 rounded-full bg-accent/10">
                      <MapPin className="text-accent" size={24} />
                    </div>
                    <div>
                      <div className="font-medium mb-1">Ubicación</div>
                      <div className="text-muted-foreground">Valencia, España</div>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="p-3 rounded-full bg-accent/10">
                      <Phone className="text-accent" size={24} />
                    </div>
                    <div>
                      <div className="font-medium mb-1">Teléfono</div>
                      <div className="text-muted-foreground">+34 643 79 06 58</div>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="p-3 rounded-full bg-accent/10">
                      <Mail className="text-accent" size={24} />
                    </div>
                    <div>
                      <div className="font-medium mb-1">Email</div>
                      <div className="text-muted-foreground">info@astralrythms.com</div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-8 border-t border-border">
                <h3 className="text-2xl font-serif font-semibold mb-4" style={{ fontFamily: "var(--font-playfair)" }}>
                  Horario de Atención
                </h3>
                <div className="space-y-2 text-muted-foreground">
                  <div className="flex justify-between">
                    <span>Lunes - Viernes</span>
                    <span className="font-medium text-foreground">9:00 - 19:00</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Sábados</span>
                    <span className="font-medium text-foreground">10:00 - 14:00</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Domingos</span>
                    <span className="font-medium text-foreground">Cerrado</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
