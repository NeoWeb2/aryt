"use client"

import { useEffect, useRef, useState } from "react"

const portfolioItems = [
  {
    title: "Boda en la Albufera",
    category: "Bodas",
    image: "/elegant-outdoor-wedding-ceremony-at-sunset-with-fl.jpg",
  },
  {
    title: "Gala Corporativa",
    category: "Eventos Corporativos",
    image: "/sophisticated-corporate-gala-dinner-with-elegant-t.jpg",
  },
  {
    title: "Celebración Íntima",
    category: "Celebraciones",
    image: "/intimate-celebration-with-candles-and-floral-cente.jpg",
  },
  {
    title: "Boda en Masía",
    category: "Bodas",
    image: "/rustic-elegant-wedding-reception-in-spanish-villa.jpg",
  },
  {
    title: "Lanzamiento de Producto",
    category: "Eventos Corporativos",
    image: "/modern-product-launch-event-with-dramatic-lighting.jpg",
  },
  {
    title: "Aniversario",
    category: "Celebraciones",
    image: "/elegant-anniversary-celebration-with-romantic-ambi.jpg",
  },
]

export function Portfolio() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    null
  )
}
