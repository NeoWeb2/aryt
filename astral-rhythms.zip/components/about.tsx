"use client"

import { useEffect, useRef, useState } from "react"

export function About() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section id="nosotros" ref={sectionRef} className="py-24 md:py-32 bg-background">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <div
            className={`transition-all duration-1000 ${
              isVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-10"
            }`}
          >
            <div className="relative aspect-[3/4] rounded-lg overflow-hidden">
              <img src="/professional-event-planner-arranging-elegant-flora.jpg" alt="Astral Rythms team" className="w-full h-full object-cover" />
            </div>
          </div>

          <div
            className={`transition-all duration-1000 delay-300 ${
              isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-10"
            }`}
          >
            <h2
              className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold mb-6 text-balance"
              style={{ fontFamily: "var(--font-playfair)" }}
            >
              Sobre Nosotros
            </h2>
            <div className="space-y-6 text-lg leading-relaxed text-muted-foreground">
              <p>
                En <span className="text-foreground font-semibold">Astral Rythms</span>, creemos que cada evento es una
                oportunidad para crear magia. Con más de una década de experiencia en Valencia, nos especializamos en
                transformar visiones en realidades extraordinarias.
              </p>
              <p>
                Nuestro equipo de profesionales apasionados trabaja con dedicación absoluta para asegurar que cada
                detalle refleje tu personalidad y supere tus expectativas. Desde bodas íntimas hasta grandes
                celebraciones, nos comprometemos con la excelencia en cada proyecto.
              </p>
              <p>
                La creatividad, la atención al detalle y el servicio personalizado son los pilares de nuestra filosofía.
                Porque tu evento no es solo una fecha en el calendario, es un momento que merece ser perfecto.
              </p>
            </div>

            <div className="grid grid-cols-3 gap-8 mt-12 pt-12 border-t border-border">
              <div>
                <div
                  className="text-4xl font-serif font-bold mb-2 text-foreground"
                  style={{ fontFamily: "var(--font-playfair)" }}
                >
                  10+
                </div>
                <div className="text-sm text-muted-foreground">Años de experiencia</div>
              </div>
              <div>
                <div
                  className="text-4xl font-serif font-bold mb-2 text-foreground"
                  style={{ fontFamily: "var(--font-playfair)" }}
                >
                  500+
                </div>
                <div className="text-sm text-muted-foreground">Eventos realizados</div>
              </div>
              <div>
                <div
                  className="text-4xl font-serif font-bold mb-2 text-foreground"
                  style={{ fontFamily: "var(--font-playfair)" }}
                >
                  100%
                </div>
                <div className="text-sm text-muted-foreground">Dedicación</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
