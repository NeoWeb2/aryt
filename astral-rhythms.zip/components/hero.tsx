"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { ArrowDown } from "lucide-react"

export function Hero() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  const scrollToServices = () => {
    const element = document.getElementById("servicios")
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img src="/elegant-wedding-reception-with-soft-lighting-and-f.jpg" alt="Elegant event" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black/60" />
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 lg:px-8 text-center">
        <div
          className={`transition-all duration-1000 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
          }`}
        >
          <h1
            className="md:text-7xl lg:text-8xl font-serif font-bold text-white mb-6 text-balance leading-tight text-2xl"
            style={{ fontFamily: "var(--font-playfair)" }}
          >
            Creamos momentos
            <br />
            que perduran
          </h1>
          <p className="text-lg md:text-xl text-white/90 mb-8 max-w-2xl mx-auto text-pretty leading-relaxed">
            Transformamos tus sueños en experiencias inolvidables. Organización de bodas y eventos exclusivos en
            Valencia.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button
              size="lg"
              onClick={scrollToServices}
              className="bg-white text-primary hover:bg-white/90 text-base px-8 py-6"
            >
              Descubre nuestros servicios
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => {
                const element = document.getElementById("contacto")
                if (element) element.scrollIntoView({ behavior: "smooth" })
              }}
              className="border-white hover:bg-white/10 text-base px-8 py-6 text-card-foreground"
            >
              Contactar y Reservar  
            </Button>
          </div>
        </div>

        {/* Scroll Indicator */}
        <button
          onClick={scrollToServices}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce"
          aria-label="Scroll down"
        >
          <ArrowDown className="text-white" size={32} />
        </button>
      </div>
    </section>
  )
}
